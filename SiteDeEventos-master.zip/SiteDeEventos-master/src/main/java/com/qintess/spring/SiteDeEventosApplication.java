package com.qintess.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SiteDeEventosApplication {

	public static void main(String[] args) {
		SpringApplication.run(SiteDeEventosApplication.class, args);
	}

}
